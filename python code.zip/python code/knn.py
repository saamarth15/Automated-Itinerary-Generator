# import the MySQLdb and sys and pants  modules
import time
import math
import argparse
import sys
import pandas
from datetime import timedelta
from pants import World, Edge
from pants import Solver
import csv
import random
import math
import operator
import pymysql
import sys

# open a database connection
# be sure to change the host IP address, username, password and database name to match your own
connection = pymysql.connect ("localhost","root","","minorproj")

# prepare a cursor object using cursor() method
cursor = connection.cursor ()

# execute the SQL query using execute() method.
sql = "SELECT gender,age FROM geo WHERE sno = 48"
cursor.execute (sql)                
# fetch the particular row
dataset=[]
data=[]
data = cursor.fetchone ()
female="Female"
male="Male"
if(data[0] == female):
    if(data[1]>=5 & data[1]<=20):
       cursor.execute("SELECT * FROM fa")
       dataset =  cursor.fetchall ()
    elif(data[1]>=21 & data[1]<=40):
       cursor.execute("SELECT * FROM fb")
       dataset =  cursor.fetchall ()
    elif(data[1]>=41 & data[1]<=90):
       cursor.execute("SELECT * FROM fc")
       dataset =  cursor.fetchall ()

elif(data[0] == male):
    if(data[1]>=5 & data[1]<=20):
       cursor.execute("SELECT * FROM ma")
       dataset =  cursor.fetchall ()
    elif(data[1]>=21 & data[1]<=40):
       cursor.execute("SELECT * FROM mb")
       dataset =  cursor.fetchall ()
    elif(data[1]>=41 & data[1]<=90):
       cursor.execute("SELECT * FROM mc")
       dataset =  cursor.fetchall ()        
print(dataset)
     
def loadDataset(trainingSet=[],testSet=[]):
	    z = len(dataset)-1
	
	    for x in range(0,len(dataset)-2):
	       
	            #dataset[x][y] = float(dataset[x][y])
	            trainingSet.append(dataset[x])         
	    
	    #dataset[z][y] = float(dataset[z][y])
	    testSet.append(dataset[z])
	
def euclideanDistance(instance1, instance2):
    distance = 0
    X= (float(instance1[8]) - float(instance2[8])) +(float(instance1[7]) - float(instance2[7]))
    distance += pow(X, 2)
    return math.sqrt(distance)

def getNeighbors(trainingSet, testInstance, k):
    distances = []
    for x in range(0,len(trainingSet)):
        dist = euclideanDistance(testInstance, trainingSet[x])
        distances.append((trainingSet[x], dist))
    distances.sort(key=operator.itemgetter(1))
    neighbors = []
    for x in range(k):
        neighbors.append(distances[x][0])
    return neighbors

#a=b=c=d=e=f=g=h=0

def main():
	trainingSet=[]
	testSet=[]
	loadDataset(trainingSet, testSet)
	print ('Train set: ' + repr(len(trainingSet)))
	print ('Test set: ' + repr(len(testSet)))
	k = 4
	neighbors = getNeighbors(trainingSet, testSet[0], k)
	l=m=n=0
	for l in range(0,k):
		a=str(neighbors[l][0])        
		b=str(neighbors[l][7])
		c=str(neighbors[l][8])
		sql1="insert into knn(places,latitude,longitude) values(%s,%s,%s)"
		cursor.execute(sql1,(a,b,c))
		connection.commit()
		print(' Nearest Neighbour is '+a+ '  whose latitude difference is: '+b+ ' and longitude differnce is '+c)
        

                
main()

